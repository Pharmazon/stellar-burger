import React from 'react';
import withFetch from '../hocs/with-fetch.js';

const App = () => {
  const WithFetchFilm = withFetch(); 
}