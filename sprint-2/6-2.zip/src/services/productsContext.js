import React from 'react';

export const PromoContext = React.createContext('');